package br.com.tokiomarine.resseguro.demoapi.resource.dto;

public record DemoResponse(
        String response
) {
}