package br.com.tokiomarine.resseguro.demoapi.resource;

import br.com.tokiomarine.resseguro.demoapi.resource.dto.DemoRequest;
import br.com.tokiomarine.resseguro.demoapi.resource.dto.DemoResponse;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoResource {
    @PostMapping("/demo")
    @ResponseStatus(HttpStatus.OK)
    public DemoResponse getMessage(@RequestBody @Validated final DemoRequest request) {
        return new DemoResponse(request.name());
    }
}
