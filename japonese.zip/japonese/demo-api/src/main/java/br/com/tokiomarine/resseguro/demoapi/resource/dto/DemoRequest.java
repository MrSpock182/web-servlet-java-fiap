package br.com.tokiomarine.resseguro.demoapi.resource.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

public record DemoRequest(
        @NotBlank
        String name,
        @Max(value = 10)
        @Min(value = 1)
        Integer age
) {
}