package br.com.tokiomarine.resseguro.apigateway;

import br.com.tokiomarine.resseguro.apigateway.repository.UserRepositoryWithMongodb;
import br.com.tokiomarine.resseguro.apigateway.repository.dto.UserOrm;
import br.com.tokiomarine.resseguro.apigateway.repository.dto.UserRoleOrm;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;

import java.util.List;
import java.util.UUID;

@EnableFeignClients
@SpringBootApplication
public class ApiGatewayApplication implements CommandLineRunner {
    public final UserRepositoryWithMongodb repository;

    public ApiGatewayApplication(UserRepositoryWithMongodb repository) {
        this.repository = repository;
    }

    public static void main(String[] args) {
        SpringApplication.run(ApiGatewayApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
//        UserOrm orm = new UserOrm();
//        orm.setId(UUID.randomUUID().toString());
//        orm.setUsername("kleber");
//        orm.setPassword("123456");
//        orm.setRoles(List.of(new UserRoleOrm("USER")));
//        orm.setEnabled(true);
//
//        repository.save(orm);
    }
}