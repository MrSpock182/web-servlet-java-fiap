package br.com.tokiomarine.resseguro.apigateway.resource.dto;

public record DemoResponse(
        String response
) {
}