package br.com.tokiomarine.resseguro.apigateway.repository.dto;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

@Document(collection = "user_resseguro")
public class UserOrm implements UserDetails {
    private String id;
    private String username;
    private String password;
    private List<UserRoleOrm> roles;
    private Boolean enabled;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    @Override
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    @Override
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public List<UserRoleOrm> getRoles() {
        return roles;
    }

    public void setRoles(List<UserRoleOrm> roles) {
        this.roles = roles;
    }

    public Boolean getEnabled() {
        return enabled;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return roles;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        if (enabled == null) {
            enabled = true;
        }
        return enabled;
    }

    public boolean hasRole(String roleName) {
        return roles.stream().anyMatch(role -> role.name().equals(roleName));
    }

    public void setEnabled(Boolean enabled) {
        this.enabled = enabled;
    }

}