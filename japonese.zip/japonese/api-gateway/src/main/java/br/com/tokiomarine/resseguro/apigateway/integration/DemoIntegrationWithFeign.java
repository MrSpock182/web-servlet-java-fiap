package br.com.tokiomarine.resseguro.apigateway.integration;

import br.com.tokiomarine.resseguro.apigateway.resource.dto.DemoRequest;
import br.com.tokiomarine.resseguro.apigateway.resource.dto.DemoResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(
        name = "demo-integration",
        url = "http://localhost:8081")
public interface DemoIntegrationWithFeign {
    @PostMapping("/demo")
    DemoResponse getInfo(@RequestBody final DemoRequest request);
}
