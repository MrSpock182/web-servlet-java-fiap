package br.com.tokiomarine.resseguro.apigateway.resource;

import br.com.tokiomarine.resseguro.apigateway.integration.DemoIntegrationWithFeign;
import br.com.tokiomarine.resseguro.apigateway.resource.dto.DemoRequest;
import br.com.tokiomarine.resseguro.apigateway.resource.dto.DemoResponse;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoResource implements GatewayResource {
    private final DemoIntegrationWithFeign demoIntegration;

    public DemoResource(DemoIntegrationWithFeign demoIntegration) {
        this.demoIntegration = demoIntegration;
    }

    @PostMapping("/demo")
    @ResponseStatus(HttpStatus.OK)
    public DemoResponse demo(final Authentication authentication, @RequestBody final DemoRequest request) {
        System.out.println(authentication.getName());
        return demoIntegration.getInfo(request);
    }
}