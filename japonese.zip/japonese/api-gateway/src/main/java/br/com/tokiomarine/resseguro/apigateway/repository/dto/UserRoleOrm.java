package br.com.tokiomarine.resseguro.apigateway.repository.dto;

import org.springframework.security.core.GrantedAuthority;

public record UserRoleOrm(
    String name
) implements GrantedAuthority {
    @Override
    public String getAuthority() {
        return this.name;
    }
}