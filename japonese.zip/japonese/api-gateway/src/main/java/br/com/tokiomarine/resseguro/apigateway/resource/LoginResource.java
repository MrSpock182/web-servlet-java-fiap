package br.com.tokiomarine.resseguro.apigateway.resource;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LoginResource {
    @GetMapping("/home")
    public String home() {
        return "SUCCESS";
    }

    @GetMapping("/login")
    public String login() {
        return "SUCCESS";
    }
}