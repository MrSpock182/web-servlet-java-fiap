package br.com.tokiomarine.resseguro.apigateway.repository;

import br.com.tokiomarine.resseguro.apigateway.repository.dto.UserOrm;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepositoryWithMongodb extends MongoRepository<UserOrm, String> {
    Optional<UserOrm> findByUsername(String username);
}
