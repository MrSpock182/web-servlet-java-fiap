package br.com.tokiomarine.resseguro.apigateway.resource;

import org.springframework.web.bind.annotation.RequestMapping;

@RequestMapping("/resseguro")
public interface GatewayResource {
}
