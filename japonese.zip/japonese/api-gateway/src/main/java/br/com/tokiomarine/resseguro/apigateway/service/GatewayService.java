package br.com.tokiomarine.resseguro.apigateway.service;

import br.com.tokiomarine.resseguro.apigateway.repository.UserRepositoryWithMongodb;
import br.com.tokiomarine.resseguro.apigateway.repository.dto.UserOrm;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import java.util.Optional;

public class GatewayService implements UserDetailsService {
    private final UserRepositoryWithMongodb repository;

    public GatewayService(UserRepositoryWithMongodb repository) {
        this.repository = repository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<UserOrm> optional = repository.findByUsername(username);
        if (optional.isEmpty()) {
            throw new NullPointerException("User not found");
        }
        return optional.get();
    }
}
