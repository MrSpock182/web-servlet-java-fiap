package br.com.tokiomarine.cobranca.lambdacancellation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LambdaCancellationApplication {
    public static void main(String[] args) {
        SpringApplication.run(LambdaCancellationApplication.class, args);
    }
}