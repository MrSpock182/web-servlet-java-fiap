package br.com.tokiomarine.cobranca.lambdacancellation.resource;

import br.com.tokiomarine.cobranca.lambdacancellation.messaging.AdyenCancellationProducer;
import br.com.tokiomarine.cobranca.lambdacancellation.resource.dto.AdyenRequest;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/v1/webhook")
public class WebhookResource {
    private final AdyenCancellationProducer messageProducer;

    public WebhookResource(AdyenCancellationProducer messageProducer) {
        this.messageProducer = messageProducer;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.OK)
    public void adyen(@RequestBody final AdyenRequest request) {
        messageProducer.sendMessage(request);
    }

}