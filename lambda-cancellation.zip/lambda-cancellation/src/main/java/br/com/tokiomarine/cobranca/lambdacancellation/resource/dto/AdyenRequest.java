package br.com.tokiomarine.cobranca.lambdacancellation.resource.dto;

public record AdyenRequest(
        String id
) {
}