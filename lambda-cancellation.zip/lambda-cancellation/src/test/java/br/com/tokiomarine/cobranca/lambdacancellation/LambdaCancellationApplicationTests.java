package br.com.tokiomarine.cobranca.lambdacancellation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LambdaCancellationApplicationTests {

	@Test
	void contextLoads() {
	}

}
