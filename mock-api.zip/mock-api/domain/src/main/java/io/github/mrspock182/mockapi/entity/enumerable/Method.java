package io.github.mrspock182.mockapi.entity.enumerable;

public enum Method {
    GET,
    POST,
    PUT,
    DELETE
}
