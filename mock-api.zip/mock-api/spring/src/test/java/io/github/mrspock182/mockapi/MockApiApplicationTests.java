package io.github.mrspock182.mockapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
