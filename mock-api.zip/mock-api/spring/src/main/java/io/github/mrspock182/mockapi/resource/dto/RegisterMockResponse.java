package io.github.mrspock182.mockapi.resource.dto;

public record RegisterMockResponse(
        String url
) {
}